#include "include/cmdline.h"
#include <iostream>
#include <cmath>
#include <stdlib.h>
#include <vector>
#include "lstm.h"
#include "fstream"

using namespace std;

double* split(string str, string pattern, int n)
{
    int pos;
	double* result = new double[n];
    str += pattern;//扩展字符串以方便操作
    int size = str.size();
	int j = 0;
    for (int i = 0; i < size; i++)
    {
        pos = str.find(pattern, i);
        if (pos < size)
        {
            string s = str.substr(i, pos - i);
            result[j] = atof(s.c_str());
            i = pos + pattern.size() - 1;
        }
		j++;
    }
    return result;
}



int main(int argc, char* argv[]){

	// 正确参数应为训练数据文件名，实际数据训练名，训练次数，异常阈值
	cmdline::parser parser;

	parser.add<string>("trainFileName", 't', "train file name", true);
	parser.add<string>("actualFileName", 'a', "actual file name", true);
	parser.add<int>("epoch", 'e', "epoch num", false, 1000);
	parser.add<double>("threshold", 's', "threshold", false, 200);
	parser.parse_check(argc, argv);

	int epoch = parser.get<int>("epoch");
	double threshold = parser.get<double>("threshold");

    // 训练集
	string trainFileName = parser.get<string>("trainFileName") + ".csv";
    ifstream trainData(trainFileName, ios::in);
    if (!trainData.is_open()) {
		cout << trainFileName << endl;
        cout << "trainData open failed!" << endl;
		return 0;
    }
    vector<double*> x;
    string temp;
    getline(trainData, temp);
	// 获得维数
    int nodeNum = 1;
	for (int i = 0; i < temp.size(); i++) {
		if (temp[i] == ',') {
			nodeNum++;
		}
	}
	do {
        x.push_back(split(temp, ",", nodeNum));
    } while(getline(trainData, temp));

	vector<double *> trainSet;
	vector<double *> labelSet;

	trainSet.assign(x.begin(), x.end()-1);
	labelSet.assign(x.begin()+1, x.end());
	x.clear();
	int hideNum = 64;
	//初始化
	Lstm *lstm = new Lstm(nodeNum, hideNum, nodeNum);

	//投入训练
	cout<<"   /*** start training ***/"<<endl;
	lstm->train(trainSet, labelSet, epoch, 0, 0.000001);
	cout<<"   /*** finish training ***/"<<endl << "#########################" << endl;
	// 在实际数据集检测异常
	cout << "   /*** start detecting ***/" << endl;

	// 训练集
	string actualFileName = parser.get<string>("actualFileName") + ".csv";
    ifstream actualData(actualFileName, ios::in);
    if (!actualData.is_open()) {
        cout << "actualData open failed!" << endl;
		return 0;
    }
	while(getline(actualData, temp)) {
        x.push_back(split(temp, ",", nodeNum));
    }
	int n = x.size();
	FOR(i, n-1){
		double *z = lstm->predict(x[i]);
		double *temp = x[i+1];
		double e = 0;
		for (int j = 0; j < nodeNum; j++) {
			cout << z[j] << " ";
			e += pow(temp[j] - z[j], 2);
		}
		cout << "   error: " << e << endl;
		// if (e > threshold) {
		// 	cout<<"test now  : "<< i << "   error: " << e <<endl;
		// }
		
		free(temp);
		free(z);
	}
	cout << "   /*** finish detecting ***/" << endl;
	lstm->~Lstm();

	FOR(i, trainSet.size()){
		free(trainSet[i]);
		free(labelSet[i]);
	}
	trainSet.clear();
	labelSet.clear();
	return 0;
}




